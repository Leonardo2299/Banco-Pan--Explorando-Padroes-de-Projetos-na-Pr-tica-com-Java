package dev.wakandaacademy.produdoro.tarefa.domain;

public enum StatusAtivacaoTarefa {
    ATIVA, INATIVA
}
