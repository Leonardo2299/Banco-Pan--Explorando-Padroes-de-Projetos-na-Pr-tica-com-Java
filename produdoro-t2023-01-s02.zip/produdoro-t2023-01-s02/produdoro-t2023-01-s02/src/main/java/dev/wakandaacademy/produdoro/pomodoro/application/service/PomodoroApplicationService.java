package dev.wakandaacademy.produdoro.pomodoro.application.service;

import dev.wakandaacademy.produdoro.pomodoro.domain.ConfiguracaoPadrao;

public interface PomodoroApplicationService {
	ConfiguracaoPadrao getConfiguracaoPadrao();
}
